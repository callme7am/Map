ALTER TABLE public."ЗУ" ADD COLUMN district_id integer;

alter table "ЗУ"
    add constraint fk_district_gid
    foreign key (district_id)
    REFERENCES округ (gid);

UPDATE public."ЗУ" zu
SET district_id = o.gid
FROM public.округ o
WHERE ST_Contains(o.geom, zu.geom);

ALTER TABLE public."ЗУ" ADD COLUMN comments TEXT;

CREATE TABLE query_archive (
    id SERIAL PRIMARY KEY,
    query_text TEXT NOT NULL,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    elapsed_time FLOAT NOT NULL
);

ALTER TABLE "ЗУ" ADD COLUMN IF NOT EXISTS address_tsv tsvector;
UPDATE "ЗУ" SET address_tsv = to_tsvector('russian', address) WHERE address IS NOT NULL;

-- Создаем триггер для автоматического обновления tsvector поля
CREATE OR REPLACE FUNCTION update_address_tsv() RETURNS trigger AS $$
BEGIN
  NEW.address_tsv := to_tsvector('russian', NEW.address);
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_update_address_tsv
BEFORE INSERT OR UPDATE ON "ЗУ"
FOR EACH ROW EXECUTE FUNCTION update_address_tsv();

-- Создаем индекс для ускорения поиска
CREATE INDEX idx_address_tsv ON "ЗУ" USING gin(address_tsv);
